/* 
 * Queries for testing SQL Server 2016 Columnstore improvements
 * by Niko Neugebauer (http://www.nikoport.com)
 * These queries are to be run on a Contoso BI Database (http://www.microsoft.com/en-us/download/details.aspx?displaylang=en&id=18279)
 *
 * These queries helps you to measure the impact of the Batch Execution Mode
 */

SET STATISTICS TIME, IO ON

ALTER DATABASE [ContosoRetailDW] SET COMPATIBILITY_LEVEL = 120
GO

-- MAXDOP = 2, Batch Mode
select sales.StoreKey, prod.ProductLabel, sum(SalesAmount)
	from dbo.FactOnlineSales sales
		inner join dbo.DimProduct prod
			on sales.ProductKey = prod.ProductKey
	where sales.UnitCost > 10
	group by sales.StoreKey,  prod.ProductLabel
	option (maxdop 2);

-- MAXDOP = 1, Batch Mode
select sales.StoreKey, prod.ProductLabel, sum(SalesAmount)
	from dbo.FactOnlineSales sales
		inner join dbo.DimProduct prod
			on sales.ProductKey = prod.ProductKey
	where sales.UnitCost > 10
	group by sales.StoreKey,  prod.ProductLabel
	option (maxdop 1);

-- MAXDOP = 1, Row Execution Mode
select sales.StoreKey, prod.ProductLabel, sum(SalesAmount)
	from dbo.FactOnlineSales sales
		inner join dbo.DimProduct prod
			on sales.ProductKey = prod.ProductKey
	where sales.UnitCost > 10
	group by sales.StoreKey,  prod.ProductLabel
	option (maxdop 1, querytraceon 9453 );

ALTER DATABASE [ContosoRetailDW] SET COMPATIBILITY_LEVEL = 130
GO