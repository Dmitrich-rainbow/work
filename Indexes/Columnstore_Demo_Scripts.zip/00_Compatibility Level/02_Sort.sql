/* 
 * Queries for testing SQL Server 2016 Columnstore improvements
 * by Niko Neugebauer (http://www.nikoport.com)
 * These queries are to be run on a Contoso BI Database (http://www.microsoft.com/en-us/download/details.aspx?displaylang=en&id=18279)
 *
 * These queries help you to observe Batch Execution Mode for the SORT iterator in action for SQL Server 2016
 */


set statistics time, io on

ALTER DATABASE [ContosoRetailDW] SET COMPATIBILITY_LEVEL = 120
GO

declare @loadDate as DateTime;

select @loadDate = sales.loadDate
	from dbo.FactOnlineSales sales
		inner join dbo.DimPromotion prom
			on sales.PromotionKey = prom.PromotionKey
	where prom.DiscountPercent = 0
	order by sales.LoadDate;


-- Spill
declare @loadDate as DateTime;

select top 450000 @loadDate = sales.loadDate
	from dbo.FactOnlineSales sales
		inner join dbo.DimPromotion prom
			on sales.PromotionKey = prom.PromotionKey
	where prom.DiscountPercent = 0
	order by sales.LoadDate

ALTER DATABASE [ContosoRetailDW] SET COMPATIBILITY_LEVEL = 130
GO