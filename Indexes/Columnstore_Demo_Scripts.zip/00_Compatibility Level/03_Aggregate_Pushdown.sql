/* 
 * Queries for testing SQL Server 2016 Columnstore improvements
 * by Niko Neugebauer (http://www.nikoport.com)
 * These queries are to be run on a Contoso BI Database (http://www.microsoft.com/en-us/download/details.aspx?displaylang=en&id=18279)
 *
 * These queries helps you to measure the impact of the Aggregate Predicate Pushdown
 */

set statistics time, io on

ALTER DATABASE [ContosoRetailDW] SET COMPATIBILITY_LEVEL = 130
GO

select max(SalesQuantity)
    from dbo.FactOnlineSales;
select max(SalesQuantity)
    from dbo.FactOnlineSales;

ALTER DATABASE [ContosoRetailDW] SET COMPATIBILITY_LEVEL = 120
GO

select max(SalesQuantity)
    from dbo.FactOnlineSales;
select max(SalesQuantity)
    from dbo.FactOnlineSales;

ALTER DATABASE [ContosoRetailDW] SET COMPATIBILITY_LEVEL = 130
GO


/* I said 8 Bytes at Maximum */
select max(SalesOrderNumber)
	from dbo.FactOnlineSales;

/* Try a Group By :) */
select sales.ProductKey, 
	sum(sales.SalesQuantity)
	from dbo.FactOnlineSales sales
	group by sales.ProductKey;
