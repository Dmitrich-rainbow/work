/* 
 * Queries for testing SQL Server 2016 Columnstore Memory Pressure
 * by Niko Neugebauer (http://www.nikoport.com)
 *
 * These queries helps you to set up a Resource Pool with low memory and a corresponding GreedyPool Workload Group
 */
 
 CREATE RESOURCE POOL [lowmemory] WITH(min_cpu_percent=0, 
		max_cpu_percent=100, 
		min_memory_percent=0, 
		max_memory_percent=20, 
		AFFINITY SCHEDULER = AUTO
)

GO

CREATE WORKLOAD GROUP [GreedyPool] WITH(group_max_requests=0, 
		importance=Medium, 
		request_max_cpu_time_sec=0, 
		request_max_memory_grant_percent=5, 
		request_memory_grant_timeout_sec=0, 
		max_dop=0) USING [lowmemory], EXTERNAL [default]

GO

ALTER RESOURCE GOVERNOR RECONFIGURE;

GO


