/* 
 * Queries for testing SQL Server 2016 Columnstore Memory Pressure
 * by Niko Neugebauer (http://www.nikoport.com)
 *
 * These queries help you to set up a classifier function to be used in conjunction with a GreedyPool Workload Group and 'NikoSlow' user
 */
CREATE FUNCTION fnUserClassifier()  
	RETURNS sysname  
		WITH SCHEMABINDING  
AS  
BEGIN  
    DECLARE @WorkloadGroup AS SYSNAME
	IF(SUSER_NAME() = 'NikoSlow')
		SET @WorkloadGroup = 'GreedyPool'
	ELSE
		SET @WorkloadGroup = 'default'
	RETURN @WorkloadGroup
END  
GO  

ALTER RESOURCE GOVERNOR
	WITH (CLASSIFIER_FUNCTION=dbo.fnUserClassifier);
GO

ALTER RESOURCE GOVERNOR RECONFIGURE
GO
