/* 
 * Queries for testing SQL Server 2016 Columnstore Memory Pressure
 * by Niko Neugebauer (http://www.nikoport.com)
 * These queries are to be run on a Contoso BI Database (http://www.microsoft.com/en-us/download/details.aspx?displaylang=en&id=18279)
 *
 * Testing Maintenance Rebuilds and Row Group Sizes
 */
use ContosoRetailDW;

--Include execution plan
alter table dbo.FactOnlineSales
	rebuild;

-- Check on the Row Groups status
SELECT rg.total_rows, 
		i.object_id, object_name(i.object_id) AS TableName, 
		i.name AS IndexName, i.index_id, i.type_desc, 
		rg.*
	FROM sys.indexes AS i
	INNEr JOIN sys.column_store_row_groups AS rg
		ON i.object_id = rg.object_id
	AND i.index_id = rg.index_id 
	ORDER BY object_name(i.object_id), i.name, row_group_id;

exec dbo.cstore_GetRowGroupsDetails @tableName = 'FactOnlineSales'

-- **********************************************************************************************************
-- Change to a different user, with a very low limit on memory resources 
-- (You will need to configure this user access and all necessary details in Resource Governor)
-- 
alter table dbo.FactOnlineSales
	rebuild;

-- Check on the Row Groups status, with a different account you should see 
SELECT rg.total_rows, 
		i.object_id, object_name(i.object_id) AS TableName, 
		i.name AS IndexName, i.index_id, i.type_desc, 
		rg.*
	FROM sys.indexes AS i
	INNEr JOIN sys.column_store_row_groups AS rg
		ON i.object_id = rg.object_id
	AND i.index_id = rg.index_id 
	ORDER BY object_name(i.object_id), i.name, row_group_id;

EXEC dbo.cstore_getRowGroups @tableName = 'FactOnlineSales';
