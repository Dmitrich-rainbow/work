/* 
 * Queries for testing SQL Server 2016 Columnstore Dictionary Pressure
 * by Niko Neugebauer (http://www.nikoport.com)
 *
 * Dictionary Pressure Demo - observe the DMVs
 */
 
use Columnstore_Play;

select *
	from sys.column_store_row_groups
	where object_id = object_id('dbo.t_colstore')


select *
	from sys.column_store_segments seg
	inner join sys.partitions p
		ON seg.hobt_id = p.hobt_id
	where object_id = object_id('dbo.t_colstore')


select *
	from sys.column_store_dictionaries dict
	inner join sys.partitions p
		ON dict.hobt_id = p.hobt_id
	where object_id = object_id('dbo.t_colstore')

