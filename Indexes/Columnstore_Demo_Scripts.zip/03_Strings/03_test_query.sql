/* 
 * Queries for testing SQL Server 2016 String Improvements
 * by Niko Neugebauer (http://www.nikoport.com)
 *
 * This script will show the distinct values within the lineitem_cci table
 */


-- View different Ship Modes
SELECT l_shipmode as ShipMode, COUNT(*) as ItemsCount
	FROM [dbo].[lineitem_cci]
	GROUP BY l_shipmode 