/* 
 * Queries for testing SQL Server 2016 String Improvements
 * by Niko Neugebauer (http://www.nikoport.com)
 *
 * This script will create the alternative Dimesion for the Ship Mode, showing the improvement for the String Design within dimensions
 */
 

DROP TABLE IF EXISTS dbo.DimShipMode;

CREATE TABLE dbo.DimShipMode(
	shipmode_id tinyint IDENTITY(1,1) NOT NULL PRIMARY KEY CLUSTERED,
	shipmode char(10) NOT NULL );

INSERT INTO dbo.DimShipMode
	(shipmode)
	VALUES ('UNKNOWN');

INSERT INTO dbo.DimShipMode
	(shipmode)
	SELECT l_shipmode
		FROM [dbo].[lineitem_cci]
		GROUP BY l_shipmode;

INSERT INTO dbo.lineitem_cci_optimised WITH (TABLOCK)
	(l_shipdate, l_orderkey, l_discount, l_extendedprice, l_suppkey, l_quantity, l_returnflag, l_partkey, l_linestatus, l_tax, l_commitdate, l_receiptdate, l_shipmode_new, l_linenumber, l_shipinstruct, l_comment)
SELECT [l_shipdate]
      ,[l_orderkey]
      ,[l_discount]
      ,[l_extendedprice]
      ,[l_suppkey]
      ,[l_quantity]
      ,[l_returnflag]
      ,[l_partkey]
      ,[l_linestatus]
      ,[l_tax]
      ,[l_commitdate]
      ,[l_receiptdate]
      ,m.shipmode_id         --- This is our ShipMode, but stored as a 
      ,[l_linenumber]
      ,[l_shipinstruct]
      ,[l_comment]
  FROM [tpch].[dbo].[lineitem_cci] c
  INNER JOIN dbo.DimShipMode m
	ON c.l_shipmode = m.shipmode;	

alter table [dbo].[lineitem_cci_optimised]
	WITH CHECK ADD CONSTRAINT [fk_lineitem_cci_optimised_shipmode] 
		FOREIGN KEY([l_shipmode_new])
			REFERENCES [dbo].DimShipMode (shipmode_id);	