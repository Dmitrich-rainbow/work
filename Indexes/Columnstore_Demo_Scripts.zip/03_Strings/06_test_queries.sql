/* 
 * Queries for testing SQL Server 2016 String Improvements
 * by Niko Neugebauer (http://www.nikoport.com)
 *
 * This script will test the String design on the TPCH database
 */
 
 SET STATISTICS TIME, IO ON

SELECT TOP 3 l_shipinstruct
	, SUM(l_quantity) as Quantity
	, COUNT(distinct l_orderkey) as DistinctOrders
	, MAX(l_comment) as BiggestComment
	FROM [dbo].[lineitem_cci]
	WHERE ISNULL(l_shipmode,'RAIL') = 'RAIL' and l_comment not like 'furiosly%'
	GROUP BY l_shipinstruct;

-- The 2nd query is 2 times faster
SELECT TOP 3 l_shipinstruct
	, SUM(l_quantity) as Quantity
	, COUNT(distinct l_orderkey) as DistinctOrders5
	, MAX(l_comment) as BiggestComment
	FROM [dbo].[lineitem_cci_optimised] cci
		INNER JOIN dbo.DimShipMode ship
			ON cci.l_shipmode_new = ship.shipmode_id 
	WHERE ISNULL(ship.shipmode,'RAIL') = 'RAIL' and l_comment not like 'furiosly%'
	GROUP BY l_shipinstruct;