/* 
 * Queries for testing SQL Server 2016 String Improvements
 * by Niko Neugebauer (http://www.nikoport.com)
 *
 * This script will test String Predicate Pushdown on the lineitem_cci table from TPCH database
 */

set statistics io on

SELECT TOP 3 l_shipinstruct
	, SUM(l_quantity) as Quantity
	FROM [dbo].[lineitem_cci]
	WHERE l_comment not like 'furiosly%'
	GROUP BY l_shipinstruct
	ORDER BY SUM(l_quantity) DESC;