/* 
 * Queries for testing SQL Server 2016 String Improvements
 * by Niko Neugebauer (http://www.nikoport.com)
 *
 * This script tests dictionaries of the LINEITEM_CCI_DELTA & LINEITEM_DELTA tables from the TPCH Database
 */

set statistics time, io on

select distinct l_shipmode
	from dbo.lineitem_cci_delta 
	where l_shipmode = 'AIR'
	

select distinct l_shipmode
	from dbo.lineitem_delta
	where l_shipmode = 'AIR'