/* 
 * Queries for testing SQL Server 2016 String Improvements
 * by Niko Neugebauer (http://www.nikoport.com)
 *
 * This script tests dictionaries of the ORDERS_CCI table
 * The functions cstore_getDictionaries & cstore_getRowGroupsDetails are to be found within CISL library (https://github.com/NikoNeugebauer/CISL)
 * 64000 entries is a magic number, after which no predicate is being pushed
 */

-- Take a detailed look at the column 9, - 'o_comment'
exec dbo.cstore_getDictionaries @tableName = 'orders_cci';

-- Verify Table's dictionaries
exec dbo.cstore_getRowGroupsDetails @tableName = 'orders_cci';