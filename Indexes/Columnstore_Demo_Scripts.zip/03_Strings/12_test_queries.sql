/* 
 * Queries for testing SQL Server 2016 String Improvements
 * by Niko Neugebauer (http://www.nikoport.com)
 *
 * This script tests different aspects of the String Predicate Pushdown
 */

set statistics time, io on

declare @res bigint;
select distinct @res = o_orderkey
	from dbo.orders_cci
	WHERE o_comment like 'regular%'
	option (maxdop 1);
GO

declare @res bigint;
select distinct @res = o_orderkey
	from dbo.orders_cci
	WHERE o_clerk > 'Clerk#0000007%'
	option (maxdop 1);
GO

declare @res bigint;
select distinct @res = o_orderkey
	from dbo.orders_cci
	WHERE [o_orderpriority]  like '%4-NOT SPECIFIED%'
	option (maxdop 1);