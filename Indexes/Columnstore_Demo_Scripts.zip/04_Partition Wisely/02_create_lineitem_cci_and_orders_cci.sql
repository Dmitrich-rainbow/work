/* 
 * Queries for testing SQL Server Columnstore Partitioning
 * by Niko Neugebauer (http://www.nikoport.com)
 *
 * This script will create lineitem_cci & orders_cci tables with columnstore index
 * on the TPCH database
 */
 
 USE [tpch]
GO

drop table if exists dbo.lineitem_cci;

-- Data Loding
SELECT [l_shipdate]
      ,[l_orderkey]
      ,[l_discount]
      ,[l_extendedprice]
      ,[l_suppkey]
      ,[l_quantity]
      ,[l_returnflag]
      ,[l_partkey]
      ,[l_linestatus]
      ,[l_tax]
      ,[l_commitdate]
      ,[l_receiptdate]
      ,[l_shipmode]
      ,[l_linenumber]
      ,[l_shipinstruct]
      ,[l_comment]
  into dbo.lineitem_cci
  FROM [dbo].[lineitem];
GO

-- Create Clustered Columnstore Index
create clustered columnstore index cci_lineitem_cci
	on dbo.lineitem_cci;

USE [tpch]
GO

DROP TABLE IF EXISTS dbo.orders_cci;

SELECT [o_orderdate]
      ,[o_orderkey]
      ,[o_custkey]
      ,[o_orderpriority]
      ,[o_shippriority]
      ,[o_clerk]
      ,[o_orderstatus]
      ,[o_totalprice]
      ,[o_comment]
	into dbo.orders_cci
  FROM [dbo].[orders];

create clustered columnstore index cci_orders_cci
	on dbo.orders_cci;
GO