/* 
 * Queries for testing SQL Server Columnstore Partitioning
 * by Niko Neugebauer (http://www.nikoport.com)
 *
 * This script will run basic aggregate queries against the lineitem table
 * on the TPCH database
 */

USE TPCH;

set statistics time, io on

select SUM(l_discount)
	from dbo.lineitem_cci

select SUM(l_discount)
	from dbo.lineitem_cci_part -- daily

select SUM(l_discount)
	from dbo.lineitem_cci_part_month -- monthly