/* 
 * Queries for testing SQL Server Columnstore Partitioning
 * by Niko Neugebauer (http://www.nikoport.com)
 *
 * This script will create lineitem_cci_part_month monthly partitioned table with columnstore index 
 * on the TPCH database
 */

DECLARE @bigString NVARCHAR(MAX) = '',
		@partFunction NVARCHAR(MAX);	


;WITH cte AS (
	SELECT CAST( '1 Jan 1992' AS DATE ) testDate
	UNION ALL
	SELECT DATEADD( month, 1, testDate )
		FROM cte
		WHERE testDate < '31 Dec 1998'
)
SELECT @bigString += ',' + QUOTENAME( CONVERT ( VARCHAR, testDate, 106 ), '''' )
	FROM cte
	OPTION ( MAXRECURSION 5000 )


SELECT @partFunction = 'CREATE PARTITION FUNCTION fn_MonthlyPartition (DATE) AS RANGE RIGHT FOR VALUES ( ' + cast(STUFF( @bigString, 1, 1, '' )as nvarchar(max)) + ' )'
print @partFunction;
EXEC sp_Executesql @partFunction


CREATE PARTITION SCHEME ps_MonthlyPartScheme 
	AS PARTITION fn_MonthlyPartition 
		ALL TO ( [PRIMARY] );

drop table if exists dbo.lineitem_cci_part_month

-- Data Loding
SELECT [l_shipdate]
      ,[l_orderkey]
      ,[l_discount]
      ,[l_extendedprice]
      ,[l_suppkey]
      ,[l_quantity]
      ,[l_returnflag]
      ,[l_partkey]
      ,[l_linestatus]
      ,[l_tax]
      ,[l_commitdate]
      ,[l_receiptdate]
      ,[l_shipmode]
      ,[l_linenumber]
      ,[l_shipinstruct]
      ,[l_comment]
  into dbo.lineitem_cci_part_month
  FROM [dbo].[lineitem]
  where 1 = 0;
GO


-- Create Clustered  Index
create clustered index cci_lineitem_cci_part_month
	on dbo.lineitem_cci_part_month ( [l_shipdate] )
		WITH (DATA_COMPRESSION = PAGE)
			ON ps_MonthlyPartScheme( [l_shipdate] ); 

-- Create Clustered Columnstore Index
create clustered columnstore index cci_lineitem_cci_part_month
	on dbo.lineitem_cci_part_month
		WITH (DROP_EXISTING = ON)
			ON ps_MonthlyPartScheme( [l_shipdate] );

insert into dbo.lineitem_cci_part_month (l_shipdate, l_orderkey, l_discount, l_extendedprice, l_suppkey, l_quantity, l_returnflag, l_partkey, l_linestatus, l_tax, l_commitdate, l_receiptdate, l_shipmode, l_linenumber, l_shipinstruct, l_comment)
SELECT [l_shipdate]
      ,[l_orderkey]
      ,[l_discount]
      ,[l_extendedprice]
      ,[l_suppkey]
      ,[l_quantity]
      ,[l_returnflag]
      ,[l_partkey]
      ,[l_linestatus]
      ,[l_tax]
      ,[l_commitdate]
      ,[l_receiptdate]
      ,[l_shipmode]
      ,[l_linenumber]
      ,[l_shipinstruct]
      ,[l_comment]
  FROM [dbo].[lineitem_cci]

alter index cci_lineitem_cci_part_month
	on dbo.lineitem_cci_part_month
	reorganize with (COMPRESS_ALL_ROW_GROUPS = ON);