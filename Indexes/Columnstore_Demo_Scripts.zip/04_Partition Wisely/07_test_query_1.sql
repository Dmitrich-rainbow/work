/* 
 * Queries for testing SQL Server Columnstore Partitioning
 * by Niko Neugebauer (http://www.nikoport.com)
 *
 * This script will test the sum aggregation against 3 tables (non-partitioned, daily partitioned & monthly partitioned)
 * on the TPCH database
 */

set statistics time, io on

select SUM(l_discount)
	from dbo.lineitem_cci

select SUM(l_discount)
	from dbo.lineitem_cci_part

select SUM(l_discount)
	from dbo.lineitem_cci_part_month