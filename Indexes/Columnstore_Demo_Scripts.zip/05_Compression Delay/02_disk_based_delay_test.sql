/* 
 * Queries for testing SQL Server 2016 Columnstore improvements
 * by Niko Neugebauer (http://www.nikoport.com)
 * These queries are to be run on a Contoso BI Database (http://www.microsoft.com/en-us/download/details.aspx?displaylang=en&id=18279)
 *
 * Testing the compression delay for the disk-based Columnstore Indexes
 */
 
CREATE TABLE [dbo].[FactOnlineSales_NCCI](
	[OnlineSalesKey] [int]  NOT NULL,
	[DateKey] [datetime] NOT NULL,
	[StoreKey] [int] NOT NULL,
	[ProductKey] [int] NOT NULL,
	[PromotionKey] [int] NOT NULL,
	[CurrencyKey] [int] NOT NULL,
	[CustomerKey] [int] NOT NULL,
	[SalesOrderNumber] [nvarchar](20) NOT NULL,
	[SalesOrderLineNumber] [int] NULL,
	[SalesQuantity] [int] NOT NULL,
	[SalesAmount] [money] NOT NULL,
	[ReturnQuantity] [int] NOT NULL,
	[ReturnAmount] [money] NULL,
	[DiscountQuantity] [int] NULL,
	[DiscountAmount] [money] NULL,
	[TotalCost] [money] NOT NULL,
	[UnitCost] [money] NULL,
	[UnitPrice] [money] NULL,
	[ETLLoadID] [int] NULL,
	[LoadDate] [datetime] NULL,
	[UpdateDate] [datetime] NULL,
	index NCCI_Test Nonclustered Columnstore (OnlineSalesKey, DateKey, StoreKey, ProductKey, PromotionKey, CurrencyKey, CustomerKey, SalesOrderNumber, SalesOrderLineNumber, SalesQuantity, SalesAmount, ReturnQuantity, ReturnAmount, DiscountQuantity, DiscountAmount, TotalCost, UnitCost, UnitPrice, ETLLoadID, LoadDate, UpdateDate)
) ON [PRIMARY]

GO

-- Set up the Compression delay to 30 Minutes
alter index NCCI_Test
	on dbo.FactOnlineSales_NCCI
     set ( COMPRESSION_DELAY = 30 Minutes );
	 
-- Execute the data loading of 100000 rows 11 times with G0 11	 
insert into dbo.FactOnlineSales_NCCI
select top 100000 OnlineSalesKey, DateKey, StoreKey, ProductKey, PromotionKey, CurrencyKey, CustomerKey, SalesOrderNumber, SalesOrderLineNumber, SalesQuantity, SalesAmount, ReturnQuantity, ReturnAmount, DiscountQuantity, DiscountAmount, TotalCost, UnitCost, UnitPrice, ETLLoadID, LoadDate, UpdateDate
	from dbo.FactOnlineSales;
GO 11 

-- Using CISL verify the internal structures of the FactOnlineSales table
exec dbo.cstore_GetRowGroupsDetails @tableName = 'FactOnlineSales_NCCI'

-- Wait for 5 minutes (default Tuple Mover delay)
waitfor delay '00:05';

-- Using CISL verify the internal structures of the FactOnlineSales table
exec dbo.cstore_GetRowGroupsDetails @tableName = 'FactOnlineSales_NCCI'

-- ******************************************************************************************************
-- Reset the Compression Delay to be instant
alter index NCCI_Test
	on dbo.FactOnlineSales_NCCI
     set ( COMPRESSION_DELAY = 0 Minutes );

-- Cleanup the table
Truncate table dbo.FactOnlineSales_NCCI;
GO

-- Execute the data loading 11 times with G0 11	 
insert into dbo.FactOnlineSales_NCCI
select top 100000 OnlineSalesKey, DateKey, StoreKey, ProductKey, PromotionKey, CurrencyKey, CustomerKey, SalesOrderNumber, SalesOrderLineNumber, SalesQuantity, SalesAmount, ReturnQuantity, ReturnAmount, DiscountQuantity, DiscountAmount, TotalCost, UnitCost, UnitPrice, ETLLoadID, LoadDate, UpdateDate
	from dbo.FactOnlineSales;
GO 11 

-- Using CISL verify the internal structures of the FactOnlineSales table
exec dbo.cstore_GetRowGroupsDetails @tableName = 'FactOnlineSales_NCCI'

-- Wait for 5 minutes (default Tuple Mover delay)
waitfor delay '00:05';

-- Using CISL verify the internal structures of the FactOnlineSales table
exec dbo.cstore_GetRowGroupsDetails @tableName = 'FactOnlineSales_NCCI'
