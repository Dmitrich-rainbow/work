/* 
 * Queries for testing SQL Server 2016 Columnstore improvements
 * by Niko Neugebauer (http://www.nikoport.com)
 * These queries are to be run on a Contoso BI Database (http://www.microsoft.com/en-us/download/details.aspx?displaylang=en&id=18279)
 *
 * Testing the compression delay for the inmemory Columnstore Indexes
 */
 USE master;

ALTER DATABASE [ContosoRetailDW] 
	ADD FILEGROUP [ContosoRetailDW_Hekaton] 
	CONTAINS MEMORY_OPTIMIZED_DATA
GO

ALTER DATABASE [ContosoRetailDW]
	ADD FILE(NAME = ContosoRetailDW_HekatonDir, 
	FILENAME = 'C:\Data\xtp') 
	TO FILEGROUP [ContosoRetailDW_Hekaton];

GO

use ContosoRetailDW;

CREATE TABLE [dbo].[FactOnlineSales_Hekaton](
	[OnlineSalesKey] [int] NOT NULL,
	[DateKey] [datetime] NOT NULL,
	[StoreKey] [int] NOT NULL,
	[ProductKey] [int] NOT NULL,
	[PromotionKey] [int] NOT NULL,
	[CurrencyKey] [int] NOT NULL,
	[CustomerKey] [int] NOT NULL,
	[SalesOrderNumber] [nvarchar](20) NOT NULL,
	[SalesOrderLineNumber] [int] NULL,
	[SalesQuantity] [int] NOT NULL,
	[SalesAmount] [money] NOT NULL,
	[ReturnQuantity] [int] NOT NULL,
	[ReturnAmount] [money] NULL,
	[DiscountQuantity] [int] NULL,
	[DiscountAmount] [money] NULL,
	[TotalCost] [money] NOT NULL,
	[UnitCost] [money] NULL,
	[UnitPrice] [money] NULL,
	[ETLLoadID] [int] NULL,
	[LoadDate] [datetime] NULL,
	[UpdateDate] [datetime] NULL,
	Constraint PK_FactOnlineSales_Hekaton PRIMARY KEY NONCLUSTERED ([OnlineSalesKey]),
	INDEX NCCI_FactOnlineSales_Hekaton 
		CLUSTERED COLUMNSTORE 
) WITH (MEMORY_OPTIMIZED = ON, DURABILITY = SCHEMA_AND_DATA);

-- Insert 1.100.000 Rows 
insert into dbo.FactOnlineSales_Hekaton
	select top 1100000 *
		from dbo.FactOnlineSales
	order by OnlineSalesKey desc
GO

-- Set up the Compression delay to 30 Minutes
alter index PK_FactOnlineSales_Hekaton
	on dbo.FactOnlineSales_Hekaton
     set ( COMPRESSION_DELAY = 30 Minutes );
	 
-- Execute the data loading 11 times with G0 11	 
insert into dbo.FactOnlineSales_Hekaton
select top 100000 OnlineSalesKey, DateKey, StoreKey, ProductKey, PromotionKey, CurrencyKey, CustomerKey, SalesOrderNumber, SalesOrderLineNumber, SalesQuantity, SalesAmount, ReturnQuantity, ReturnAmount, DiscountQuantity, DiscountAmount, TotalCost, UnitCost, UnitPrice, ETLLoadID, LoadDate, UpdateDate
	from dbo.FactOnlineSales;
GO 11 

-- Using CISL verify the internal structures of the FactOnlineSales table
exec dbo.cstore_GetRowGroupsDetails @tableName = 'FactOnlineSales_Hekaton'

-- Wait for 5 minutes (default Tuple Mover delay)
waitfor delay '00:05';

-- Using CISL verify the internal structures of the FactOnlineSales table
exec dbo.cstore_GetRowGroupsDetails @tableName = 'FactOnlineSales_Hekaton'

-- ******************************************************************************************************
-- Reset the Compression Delay to be instant
alter index PK_FactOnlineSales_Hekaton
	on dbo.FactOnlineSales_Hekaton
     set ( COMPRESSION_DELAY = 0 Minutes );

-- Cleanup the table
Truncate table dbo.FactOnlineSales_Hekaton;
GO

-- Execute the data loading 11 times with G0 11	 
insert into dbo.FactOnlineSales_Hekaton
select top 100000 OnlineSalesKey, DateKey, StoreKey, ProductKey, PromotionKey, CurrencyKey, CustomerKey, SalesOrderNumber, SalesOrderLineNumber, SalesQuantity, SalesAmount, ReturnQuantity, ReturnAmount, DiscountQuantity, DiscountAmount, TotalCost, UnitCost, UnitPrice, ETLLoadID, LoadDate, UpdateDate
	from dbo.FactOnlineSales;
GO 11 

-- Using CISL verify the internal structures of the FactOnlineSales table
exec dbo.cstore_GetRowGroupsDetails @tableName = 'FactOnlineSales_Hekaton'

-- Wait for 5 minutes (default Tuple Mover delay)
waitfor delay '00:05';

-- Using CISL verify the internal structures of the FactOnlineSales table
exec dbo.cstore_GetRowGroupsDetails @tableName = 'FactOnlineSales_Hekaton'
