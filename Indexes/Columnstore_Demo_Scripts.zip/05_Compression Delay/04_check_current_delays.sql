/* 
 * Queries for testing SQL Server 2016 Columnstore improvements
 * by Niko Neugebauer (http://www.nikoport.com)
 * These queries are to be run on a Contoso BI Database (http://www.microsoft.com/en-us/download/details.aspx?displaylang=en&id=18279)
 *
 * Testing the compression delay 
 */
 
 select name, object_name(object_id) as table_name, index_id, type, type_desc, compression_delay
	from sys.indexes
	where type in (5,6);