/* 
 * Queries for testing SQL Server 2016 Columnstore improvements
 * by Niko Neugebauer (http://www.nikoport.com)
 * These queries are to be run on a Contoso BI Database (http://www.microsoft.com/en-us/download/details.aspx?displaylang=en&id=18279)
 *
 * Testing the compression delay 
 */

use tpch;

select *
	from sys.indexes
	where object_id = object_id('dbo.FactOnlineSales_NCCI');