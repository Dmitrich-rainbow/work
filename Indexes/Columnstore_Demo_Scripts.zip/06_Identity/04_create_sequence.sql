/* 
 * Queries for testing SQL Server 2016 Columnstore Identity Loading
 * by Niko Neugebauer (http://www.nikoport.com)
 * These queries are to be run on a Contoso BI Database (http://www.microsoft.com/en-us/download/details.aspx?displaylang=en&id=18279)
 *
 * This script will create a Sequence Object to be used for the loading test
 */

IF EXISTS (select * from sys.objects where type = 'SO' and name = 's1' and schema_id = SCHEMA_ID('dbo') )
	DROP SEQUENCE [dbo].[S1];

CREATE SEQUENCE [dbo].[S1] 
 AS [int]
 START WITH 1
 INCREMENT BY 1
 MINVALUE -2147483648
 MAXVALUE 2147483647
 CACHE  100000 
GO