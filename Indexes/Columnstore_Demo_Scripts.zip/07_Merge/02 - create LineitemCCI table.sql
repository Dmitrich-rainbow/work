/* 
 * Queries for testing SQL Server Columnstore Merge
 * by Niko Neugebauer (http://www.nikoport.com)
 *
 * This script will create lineitem_cci_merge table on the TPCH database
 */

USE [tpch]
GO

DROP TABLE IF EXISTS dbo.lineitem_cci_merge;

-- Data Loding
SELECT TOP 2000000
	   [l_shipdate]
      ,[l_orderkey]
      ,[l_discount]
      ,[l_extendedprice]
      ,[l_suppkey]
      ,[l_quantity]
      ,[l_returnflag]
      ,[l_partkey]
      ,[l_linestatus]
      ,[l_tax]
      ,[l_commitdate]
      ,[l_receiptdate]
      ,[l_shipmode]
      ,[l_linenumber]
      ,[l_shipinstruct]
      ,[l_comment]
  into dbo.lineitem_cci_merge
  FROM [dbo].[lineitem_cci];

-- Create Clustered Columnstore Index
create clustered columnstore index cci_lineitem_cci_merge
	on dbo.lineitem_cci_merge;