/* 
 * Queries for testing SQL Server Columnstore Merge
 * by Niko Neugebauer (http://www.nikoport.com)
 *
 * This script will create test Merge operation on the Columnstore Table within TPCH database
 */

use TPCH;

set nocount on
SET STATISTICS TIME, IO ON

-- 30 Seconds
MERGE INTO [dbo].[lineitem_cci_merge] AS [Target] 
	USING (
		SELECT
			l_shipdate, l_orderkey, l_discount, l_extendedprice, l_suppkey, l_quantity, l_returnflag, l_partkey, l_linestatus, l_tax, l_commitdate, l_receiptdate, l_shipmode, l_linenumber, l_shipinstruct, l_comment
			FROM dbo.[lineitem_cci_stage]
			
	) AS [Source] 
		ON
			Target.L_ORDERKEY = Source.L_ORDERKEY
		AND Target.L_LINENUMBER = Source.L_LINENUMBER
    WHEN MATCHED THEN
		UPDATE 
			SET l_shipdate = Source.l_shipdate, l_orderkey = Source.l_orderkey, l_discount = Source.l_discount, l_extendedprice = Source.l_extendedprice, l_suppkey = Source.l_suppkey, l_quantity = Source.l_quantity, l_returnflag = Source.l_returnflag, l_partkey = Source.l_partkey, l_linestatus = Source.l_linestatus, l_tax = Source.l_tax, l_commitdate = Source.l_commitdate, l_receiptdate = Source.l_receiptdate, l_shipmode = Source.l_shipmode, l_linenumber = Source.l_linenumber, l_shipinstruct = Source.l_shipinstruct, l_comment = Source.l_comment
	WHEN NOT MATCHED BY TARGET THEN
		INSERT (l_shipdate, l_orderkey, l_discount, l_extendedprice, l_suppkey, l_quantity, l_returnflag, l_partkey, l_linestatus, l_tax, l_commitdate, l_receiptdate, l_shipmode, l_linenumber, l_shipinstruct, l_comment)
        VALUES (Source.l_shipdate, Source.l_orderkey, Source.l_discount, Source.l_extendedprice, Source.l_suppkey, Source.l_quantity, Source.l_returnflag, Source.l_partkey, Source.l_linestatus, Source.l_tax, Source.l_commitdate, Source.l_receiptdate, Source.l_shipmode, Source.l_linenumber, Source.l_shipinstruct, Source.l_comment);