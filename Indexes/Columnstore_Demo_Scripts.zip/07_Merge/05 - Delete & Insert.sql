/* 
 * Queries for testing SQL Server Columnstore Merge
 * by Niko Neugebauer (http://www.nikoport.com)
 *
 * This script will test alternative Merge (=DELETE & INSERT) operation on the Columnstore Table within TPCH database
 */


DELETE Target 
	FROM dbo.lineitem_cci as Target
	WHERE EXISTS (
			SELECT 1
				FROM dbo.lineitem_cci_stage as Source
				WHERE Target.L_ORDERKEY = Source.L_ORDERKEY
					AND Target.L_LINENUMBER = Source.L_LINENUMBER
				);
				
INSERT INTO dbo.lineitem_cci WITH (TABLOCK)
	SELECT l_shipdate, l_orderkey, l_discount, l_extendedprice, l_suppkey, l_quantity, l_returnflag, l_partkey, l_linestatus, l_tax, l_commitdate, l_receiptdate, l_shipmode, l_linenumber, l_shipinstruct, l_comment
		FROM [dbo].[lineitem_cci_stage];	