-- Observe the Row Groups
exec dbo.cstore_GetRowGroups @tableName = 'FactOnlineSales_SSIS';