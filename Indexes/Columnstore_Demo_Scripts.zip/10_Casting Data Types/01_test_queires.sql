/* 
 * Queries for testing SQL Server Columnstore Merge
 * by Niko Neugebauer (http://www.nikoport.com)
 *
 * This script will test data type casting within TPCH database
 */

SET STATISTICS TIME, IO ON

use TPCH;

DBCC TRACEON(8666);
-- Let's test 2 almost the same queries
SELECT 
   SUM( l_quantity),
      SUM(l_discount), 
   COUNT(distinct l_commitdate)
  FROM [dbo].[lineitem_cci_string] li
	 INNER JOIN dbo.DateDimension dd
	 ON [l_receiptdate] = dd.Date

SELECT 
   SUM( l_quantity),
      SUM(l_discount), 
   COUNT(distinct l_commitdate)
  FROM [dbo].[lineitem_cci_string] li
 INNER JOIN dbo.DateDimension dd
 ON [l_receiptdate] = cast(dd.Date as varchar(10));


