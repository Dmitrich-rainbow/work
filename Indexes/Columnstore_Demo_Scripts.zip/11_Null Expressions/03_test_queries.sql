/* 
 * Queries for testing SQL Server Columnstore Merge
 * by Niko Neugebauer (http://www.nikoport.com)
 *
 * This script tests NULL expressions with the Columnstore Indexes
 */


use TPCH;

SET STATISTICS TIME, IO ON

-- The default query with ISNULL
SELECT TOP 3 l_shipinstruct
	, SUM(l_quantity) as Quantity
	, COUNT(distinct l_orderkey) as DistinctOrders
	FROM [dbo].[lineitem_cci] li
	WHERE ISNULL(l_shipmode,'RAIL') = 'RAIL'
	GROUP BY l_shipinstruct
	ORDER BY SUM(l_quantity) DESC

-- Rewrite your ISNULL() query
SELECT TOP 3 l_shipinstruct
	, SUM(l_quantity) as Quantity
	, COUNT(distinct l_orderkey) as DistinctOrders
	FROM [dbo].[lineitem_cci] li
	WHERE l_shipmode = 'RAIL' OR l_shipmode IS NULL
	GROUP BY l_shipinstruct
	ORDER BY SUM(l_quantity) DESC

-- Check on the RowStore Indexes
SELECT TOP 3 l_shipinstruct
	, SUM(l_quantity) as Quantity
	, COUNT(distinct l_orderkey) as DistinctOrders
	FROM [dbo].[lineitem] li
	WHERE l_shipmode = 'RAIL' OR l_shipmode IS NULL
	GROUP BY l_shipinstruct
	ORDER BY SUM(l_quantity) DESC