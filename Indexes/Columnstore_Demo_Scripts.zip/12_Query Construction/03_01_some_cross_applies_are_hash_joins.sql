/* 
 * Queries for testing SQL Server Columnstore Merge
 * by Niko Neugebauer (http://www.nikoport.com)
 *
 * This script shows that CROSS APPLY might be rewritten internally to use HASH JOINs
 */

select TOP 100
	o_orderkey,
	o.o_orderdate,
	MAX(o.o_totalprice) as orderprice,
	SUM(Volume) as VolumeSales	
	from dbo.orders_cci o
		cross apply ( select (l_extendedprice * (1 - l_discount)) as volume
						from lineitem_cci li
						where o_orderkey = li.l_orderkey
						 ) f
	where o.o_orderstatus <> 'F'
	group by o.o_orderdate, o_orderkey
	ORDER BY SUM(o.o_totalprice) DESC;