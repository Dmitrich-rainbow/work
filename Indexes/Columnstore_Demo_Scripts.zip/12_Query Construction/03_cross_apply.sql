/* 
 * Queries for testing SQL Server Columnstore Merge
 * by Niko Neugebauer (http://www.nikoport.com)
 *
 * This script tests CROSS APPLY with Columnstore Indexes 
 */


USE TPCH;

set statistics time, io on

select TOP 100
	o_orderkey,
	o.o_orderdate,
	MAX(o.o_totalprice) as orderprice,
	SUM(Volume) as Top10VolumeSales	
	from dbo.orders_cci o
		cross apply ( select top 10 (l_extendedprice * (1 - l_discount)) as volume
						from lineitem_cci li
						where o_orderkey = li.l_orderkey
						order by  (l_extendedprice * (1 - l_discount)) desc
						 ) f
	where o.o_orderstatus <> 'F'
	group by o.o_orderdate, o_orderkey
	ORDER BY SUM(o.o_totalprice) DESC;


-- Better Solution, using INNER JOIN and ROW_NUMER()
select TOP 100
	o.o_orderkey,
	o.o_orderdate,
	MAX(o.o_totalprice) as orderprice,
	SUM(Volume) as Top10Volume
	from dbo.orders_cci o
		inner join ( select ROW_NUMBER() OVER (PARTITION BY l_orderkey ORDER BY sum(l_extendedprice * (1 - l_discount)) desc) AS rowNumber,
						sum(l_extendedprice * (1 - l_discount)) as volume,
						li.l_orderkey
						from lineitem_cci li
						group by l_orderkey ) f
		on o_orderkey = f.l_orderkey
	where o.o_orderstatus <> 'F'
		and rowNumber < 10
	group by o.o_orderdate, o.o_orderkey
	ORDER BY SUM(o.o_totalprice) DESC