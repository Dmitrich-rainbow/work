/* 
 * Queries for testing SQL Server Columnstore Merge
 * by Niko Neugebauer (http://www.nikoport.com)
 *
 * This script shows the query writing against the TPCH database 
 */
 
 set statistics time, io on

select sum((l_extendedprice - l_discount) *1.23 * l_quantity) 
	from [tpch].[dbo].[lineitem_cci];

select sum((l_extendedprice - l_discount)*l_quantity) * 1.23
	from [tpch].[dbo].[lineitem_cci];