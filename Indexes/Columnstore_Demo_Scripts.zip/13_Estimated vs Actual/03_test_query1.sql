/* 
 * Queries for testing SQL Server Columnstore Merge
 * by Niko Neugebauer (http://www.nikoport.com)
 *
 * This script tests the performance of the simple aggregation query agaisnt the test tables
 */

SET STATISTICS IO, TIME ON

SELECT COUNT(*) as TotalRowCount
	FROM [dbo].[FactOnlineSales_SampleA];

SELECT COUNT(*) as TotalRowCount
	FROM [dbo].[FactOnlineSales_SampleB];