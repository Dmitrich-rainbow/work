/* 
 * Queries for testing SQL Server Columnstore Merge
 * by Niko Neugebauer (http://www.nikoport.com)
 *
 * This script tests the performance of the aggregation query agaisnt the test tables
 */

SET STATISTICS IO, TIME ON

SELECT SUM(TotalCost) as TotalCost
	FROM [dbo].[FactOnlineSales_SampleA]

SELECT SUM(TotalCost) as TotalCost
	FROM [dbo].[FactOnlineSales_SampleB]