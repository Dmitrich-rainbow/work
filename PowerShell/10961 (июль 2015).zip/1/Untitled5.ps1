﻿Get-Process | Get-Member
Get-Process | Sort-Object -Property CPU -Descending | Select-Object -First 1