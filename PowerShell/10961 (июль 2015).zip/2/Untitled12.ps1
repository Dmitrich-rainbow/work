﻿Get-Command -Noun ItemProperty
Get-Help Get-ItemProperty

Get-ItemProperty "C:\MyFile.txt"
Get-Item "C:\MyFile.txt"