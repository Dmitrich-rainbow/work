﻿Dir Power:
New-Item Power:\Test1 -ItemType "Folder"
New-Item Power:\Test1\Test2 -ItemType "Folder"

Dir Power:\Test1

New-Item Power:\Test1\Test2 -ItemType ...

Get-ItemProperty "Power:\Test1\Test2"


