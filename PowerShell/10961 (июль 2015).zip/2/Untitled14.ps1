﻿Dir "C:\" | Get-Member
Dir "Power:\" | Get-Member