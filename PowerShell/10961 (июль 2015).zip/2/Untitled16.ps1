﻿ClS
Dir C:\Windows | Sort-Object Length -Descending
Get-Help Sort-Object