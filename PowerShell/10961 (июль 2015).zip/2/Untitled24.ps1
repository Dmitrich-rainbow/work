﻿ClS
Dir "C:\Windows" |
Group-Object -Property Extension |
Get-Member