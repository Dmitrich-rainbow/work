﻿Dir C:\Windows |
Where-Object Length -GE 100 |
Group-Object Extension |
Where-Object count -GE 3