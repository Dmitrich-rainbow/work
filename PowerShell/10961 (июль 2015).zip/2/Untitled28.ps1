﻿Get-Command -Verb Format

ClS
Dir C:\Windows | Format-Table -Property Name, Extension, Length