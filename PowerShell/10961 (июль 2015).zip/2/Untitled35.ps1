﻿Get-Process -Name *a*
Get-Process | Sort-Object -Property Name

ClS
Get-Help Sort-Object -Full