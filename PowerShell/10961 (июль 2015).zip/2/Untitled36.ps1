﻿Dir C:\Windows | Sort-Object -Property Length -Descending

Sort-Object -Property Length -Descending -InputObject (Dir C:\Windows)