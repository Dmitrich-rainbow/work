﻿Format-Wide -InputObject (Get-Service)

Get-Service | Format-Wide
