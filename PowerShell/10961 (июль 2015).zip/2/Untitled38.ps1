﻿Get-Help Get-Service -Full

Get-Service -Name *win* 
"*win*" | Get-Service