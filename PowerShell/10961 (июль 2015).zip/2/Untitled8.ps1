﻿Dir c:\Windows
Get-Alias Dir
Get-Command -Noun ChildItem
Get-Help Get-ChildItem

Get-Alias md
Get-Alias rd
