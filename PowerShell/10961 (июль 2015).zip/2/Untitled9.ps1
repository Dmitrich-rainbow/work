﻿Get-PSProvider
Get-PSDrive

Dir c:\
Dir HKCU:\
Dir Env:\

Dir "HKCU:\Control Panel\PowerCfg"