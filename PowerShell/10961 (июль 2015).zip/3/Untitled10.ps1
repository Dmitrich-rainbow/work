﻿Get-Help New-Variable

New-Variable -Name Test1
New-Variable -Name Test2 -Value 2015
New-Variable -Name Test3 -Value "Specialist"

Get-Variable