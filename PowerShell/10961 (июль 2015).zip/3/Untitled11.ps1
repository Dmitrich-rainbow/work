﻿Get-PSDrive

Dir Variable:
Dir Variable:\Test3
Dir Variable:\PSVersionTable

$Test2
$Test3
$Test1

$PSVersionTable