﻿$PSVersionTable | Get-Member
$Test2 | Get-Member
$Test2.GetType()
$Test3.GetType()
$Test3 | Get-Member

$Test3.Length
$Test3.Substring(2, 7)

$Test1 | Get-Member