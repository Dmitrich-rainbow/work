﻿$Test4 = 100
$Test4.GetType()

$Test4 = 100.25
$Test4
$Test4.GetType()

$Test4 = "Sochi-2014"
$Test4
$Test4.GetType()
