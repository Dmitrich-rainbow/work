﻿[int]$Test5 = 100

Dir Variable:\Test?

$Test5 = 100.25 
$Test5
$Test5.GetType()

$Test5 = "Sochi-2014"
$Test5 = "2014"
$Test5 
$Test5.GetType()