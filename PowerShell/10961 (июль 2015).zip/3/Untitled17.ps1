﻿$Test7 = 10, 20, 30, 40, 50
Dir Variable:\Test*
$Test7 | GM

$Test7[0]
$Test7[1]
$Test7[1000]

$Test7.Count
$Test7[0]
$Test7[$Test7.Count - 1]
