﻿$Test7[2].GetType()
$Test7.GetType()

$Test7[2] = "Brazil-2018"
$Test7[2].GetType()

