﻿$MyFolder = "C:\"

$MyFiles = Dir $MyFolder

$MyFiles.Count