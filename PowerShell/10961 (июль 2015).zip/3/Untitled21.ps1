﻿[int]$Index = 0

While ($Index -GT 0) # Условие продолжния цикла
    {
    $Index; # Полезная нагрузка в цикле
    $Index = $Index - 1;
    }

