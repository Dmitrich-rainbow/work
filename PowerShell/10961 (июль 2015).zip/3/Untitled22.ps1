﻿[int]$Index = 0

Do
    {
    $Index; # Полезная нагрузка в цикле
    $Index = $Index - 1;
    }
While ($Index -GT 0) # Условие продолжния цикла