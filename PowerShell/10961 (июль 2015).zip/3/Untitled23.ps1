﻿ClS
[int]$Index = 8

Do
    {
    $Index; # Полезная нагрузка в цикле
    $Index = $Index - 1;
    }
Until ($Index -EQ 0) # Условие __окончания__ цикла