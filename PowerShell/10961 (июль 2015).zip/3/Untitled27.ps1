﻿ClS
[int]$Test9 = 1
$Test9

If ($Test9 -GT 3)
    {
        Write-Host "Больше трёх"
    }
