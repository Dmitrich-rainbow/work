﻿ClS
[int]$Test9 = 3
$Test9

If ($Test9 -GT 3)
    {
        Write-Host "Больше трёх"
    }
Else
    {
        Write-Host "Не больше трёх"
    }