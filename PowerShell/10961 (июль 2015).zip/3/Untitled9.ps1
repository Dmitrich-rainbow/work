﻿Get-Command -Noun Variable

Get-Variable -Name PSVersionTable | Get-Member

