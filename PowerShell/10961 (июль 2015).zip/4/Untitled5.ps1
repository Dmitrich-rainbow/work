﻿Get-Command -Verb Write
