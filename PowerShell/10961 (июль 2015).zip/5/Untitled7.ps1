﻿[CmdletBinding()]
Param(
[string]$FileName
)

Get-Content -Path $FileName