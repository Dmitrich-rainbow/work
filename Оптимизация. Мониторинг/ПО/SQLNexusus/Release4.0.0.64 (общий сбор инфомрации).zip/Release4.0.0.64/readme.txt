﻿1) For instructions on how to use data collectors, go to https://sqlnexus.codeplex.com/wikipage?title=Sql2005PerfStatsScript&referringTitle=collecting%20data%20using%20batch%20files
2) For instructions on how to use SQL Nexus go to https://sqlnexus.codeplex.com/
