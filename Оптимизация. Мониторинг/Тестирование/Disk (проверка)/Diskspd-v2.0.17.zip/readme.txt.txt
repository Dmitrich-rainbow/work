Previous Diskspd Tool Update Notes:

------------

Update 12/14/2015: Diskspd now officially supersedes SQLIO, which has been pulled from the download site. For specific guidance on using Diskspd to simulate SQL Server, please see the bundled document, UsingDiskspdforSQLServer.docx, available in the updated Diskspd download package.

------------

Update 11/20/2015: Running Diskspd on Nano Server requires the installation of the reverse forwarders package (-ReverseForwarders) for proper operation.

------------

Update 01/20/2015: Uploaded a new version of Diskspd (2.0.15 from 2.0.12), along with more robust documentation (in both docx and pdf formats).

------------